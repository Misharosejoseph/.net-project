// src/App.tsx
import React from 'react';
import AppNavigator from './navigation/AppNavigator';
import { TasksProvider } from './context/TasksContext';

export default function App() {
  return (
    <TasksProvider>
      <AppNavigator />
    </TasksProvider>
  );
}
