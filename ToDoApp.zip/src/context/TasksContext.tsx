// src/context/TasksContext.tsx
import React, { createContext, useContext, useEffect, useState } from 'react';
import { Task } from '../types/types';
import { db } from '../services/firebase';
import {
  collection,
  addDoc,
  onSnapshot,
  query,
  where,
  orderBy,
  doc,
  updateDoc,
  deleteDoc,
} from 'firebase/firestore';
import { auth } from '../services/firebase';

interface TasksContextValue {
  tasks: Task[];
  addTask: (t: Omit<Task, 'id' | 'createdAt' | 'ownerId'>) => Promise<void>;
  toggleComplete: (taskId: string, completed: boolean) => Promise<void>;
  deleteTask: (taskId: string) => Promise<void>;
}

const TasksContext = createContext<TasksContextValue | undefined>(undefined);

export const useTasks = () => {
  const ctx = useContext(TasksContext);
  if (!ctx) throw new Error('useTasks must be used inside TasksProvider');
  return ctx;
};

export const TasksProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const user = auth.currentUser;

  useEffect(() => {
    if (!user) {
      setTasks([]);
      return;
    }
    const q = query(
      collection(db, 'tasks'),
      where('ownerId', '==', user.uid),
      orderBy('createdAt', 'desc')
    );
    const unsub = onSnapshot(q, (snap) => {
      const arr: Task[] = [];
      snap.forEach((docSnap) => {
        const data = docSnap.data() as any;
        arr.push({
          id: docSnap.id,
          title: data.title,
          description: data.description,
          createdAt: data.createdAt,
          dueAt: data.dueAt ?? null,
          priority: data.priority,
          completed: data.completed,
          ownerId: data.ownerId,
        });
      });
      setTasks(arr);
    });
    return () => unsub();
  }, [user]);

  async function addTask(t: Omit<Task, 'id' | 'createdAt' | 'ownerId'>) {
    if (!auth.currentUser) throw new Error('Not authenticated');
    await addDoc(collection(db, 'tasks'), {
      ...t,
      createdAt: Date.now(),
      ownerId: auth.currentUser.uid,
    });
  }

  async function toggleComplete(taskId: string, completed: boolean) {
    const ref = doc(db, 'tasks', taskId);
    await updateDoc(ref, { completed });
  }

  async function deleteTask(taskId: string) {
    const ref = doc(db, 'tasks', taskId);
    await deleteDoc(ref);
  }

  return (
    <TasksContext.Provider value={{ tasks, addTask, toggleComplete, deleteTask }}>
      {children}
    </TasksContext.Provider>
  );
};
