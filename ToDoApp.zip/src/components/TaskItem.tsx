// src/components/TaskItem.tsx
import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Task } from '../types/types';

interface Props {
  task: Task;
  onToggle: (id: string, completed: boolean) => void;
  onDelete: (id: string) => void;
}

export default function TaskItem({ task, onToggle, onDelete }: Props) {
  return (
    <View style={[styles.container, task.completed && styles.completed]}>
      <View style={styles.row}>
        <TouchableOpacity onPress={() => onToggle(task.id, !task.completed)}>
          <Text style={styles.checkbox}>{task.completed ? '☑' : '☐'}</Text>
        </TouchableOpacity>
        <View style={styles.content}>
          <Text style={styles.title}>{task.title}</Text>
          {task.dueAt ? (
            <Text style={styles.meta}>Due: {new Date(task.dueAt).toLocaleString()}</Text>
          ) : null}
        </View>
      </View>
      <TouchableOpacity onPress={() => onDelete(task.id)}>
        <Text style={styles.del}>Delete</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 12,
    marginVertical: 6,
    backgroundColor: '#fff',
    borderRadius: 8,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 1,
  },
  row: { flexDirection: 'row', alignItems: 'center' },
  checkbox: { fontSize: 20, marginRight: 12 },
  content: {},
  title: { fontWeight: '600' },
  meta: { fontSize: 12, color: '#666' },
  del: { color: '#d00' },
  completed: { opacity: 0.6 },
});
