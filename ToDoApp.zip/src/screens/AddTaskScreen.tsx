// src/screens/AddTaskScreen.tsx
import React, { useState } from 'react';
import { View, TextInput, Button, StyleSheet, Text, Platform } from 'react-native';
import { useTasks } from '../context/TasksContext';
import { Priority } from '../types/types';
import DateTimePicker from '@react-native-community/datetimepicker';

export default function AddTaskScreen({ navigation }: any) {
  const { addTask } = useTasks();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [priority, setPriority] = useState<Priority>('medium');
  const [dueAt, setDueAt] = useState<number | null>(null);
  const [showPicker, setShowPicker] = useState(false);

  async function handleSave() {
    if (!title.trim()) return;
    await addTask({ title: title.trim(), description, priority, completed: false, dueAt });
    navigation.goBack();
  }

  return (
    <View style={styles.container}>
      <TextInput placeholder="Title" value={title} onChangeText={setTitle} style={styles.input} />
      <TextInput
        placeholder="Description"
        value={description}
        onChangeText={setDescription}
        style={[styles.input, { height: 100 }]}
        multiline
      />

      <View style={{ marginVertical: 8 }}>
        <Text>Priority</Text>
        <View style={{ flexDirection: 'row', marginTop: 8 }}>
          {(['low', 'medium', 'high'] as Priority[]).map((p) => (
            <Button key={p} title={p} onPress={() => setPriority(p)} />
          ))}
        </View>
      </View>

      <View style={{ marginVertical: 8 }}>
        <Text>Due date</Text>
        <Button title={dueAt ? new Date(dueAt).toLocaleString() : 'Pick date'} onPress={() => setShowPicker(true)} />
        {showPicker && (
          <DateTimePicker
            value={dueAt ? new Date(dueAt) : new Date()}
            mode="datetime"
            is24Hour
            display={Platform.OS === 'ios' ? 'inline' : 'default'}
            onChange={(e, d) => {
              setShowPicker(false);
              if (d) setDueAt(d.getTime());
            }}
          />
        )}
      </View>

      <Button title="Save Task" onPress={handleSave} />
    </View>
  );
}

const styles = StyleSheet.create({ container: { flex: 1, padding: 16 }, input: { borderWidth: 1, borderColor: '#ddd', padding: 10, borderRadius: 8, marginVertical: 8 }, });
