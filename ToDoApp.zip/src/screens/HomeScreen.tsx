// src/screens/HomeScreen.tsx
import React, { useEffect } from 'react';
import { View, Text, Button, FlatList, StyleSheet } from 'react-native';
import { signOut } from 'firebase/auth';
import { auth } from '../services/firebase';
import { useTasks } from '../context/TasksContext';
import TaskItem from '../components/TaskItem';

export default function HomeScreen({ navigation }: any) {
  const { tasks, toggleComplete, deleteTask } = useTasks();

  useEffect(() => {
    if (!auth.currentUser) {
      navigation.replace('Login');
    }
  }, [navigation]);

  return (
    <View style={styles.container}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 12 }}>
        <Text style={{ fontSize: 22 }}>My Tasks</Text>
        <Button title="New" onPress={() => navigation.navigate('AddTask')} />
      </View>

      <FlatList
        data={tasks}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TaskItem task={item} onToggle={toggleComplete} onDelete={deleteTask} />
        )}
        ListEmptyComponent={<Text>No tasks yet</Text>}
      />

      <View style={{ marginTop: 12 }}>
        <Button title="Logout" onPress={() => signOut(auth)} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({ container: { flex: 1, padding: 16 } });
