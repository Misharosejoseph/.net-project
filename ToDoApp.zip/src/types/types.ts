// src/types/types.ts
export type Priority = 'low' | 'medium' | 'high';

export interface Task {
  id: string;
  title: string;
  description?: string;
  createdAt: number;
  dueAt?: number | null;
  priority: Priority;
  completed: boolean;
  ownerId: string;
}
