# React Native To-Do App (TypeScript) — Ready Project

This is a ready-to-open skeleton for the assignment: React Native CLI + TypeScript To-Do app with Firebase Authentication + Firestore examples.

**Important:** Replace Firebase config values in `src/services/firebase.ts` with your project credentials.

Run instructions (after you created a React Native environment):
1. Install dependencies:
   yarn install
2. Install pods (iOS):
   cd ios && pod install
3. Run on Android:
   yarn android
4. Run on iOS:
   yarn ios

